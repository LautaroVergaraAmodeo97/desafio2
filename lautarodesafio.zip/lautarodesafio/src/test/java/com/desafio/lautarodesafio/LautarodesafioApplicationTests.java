package com.desafio.lautarodesafio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LautarodesafioApplicationTests {

	@Test
	void contextLoads() {
	}

}
